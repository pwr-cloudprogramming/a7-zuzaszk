const SERVER_URL = "http://localhost:5000";

document.getElementById('create-room-btn').addEventListener('click', function(event) {
    event.preventDefault();
    var username = document.getElementById('username').value.trim();
    sessionStorage.setItem('username', username);
    
    fetch(`${SERVER_URL}/create_room`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username: username })
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        if(data.success) {
            document.getElementById('username-form').style.display = 'none';
            document.getElementById('game-body').style.display = 'block';
        }
        else {
            alert(data.message);
        }
    })            
    .catch(error => {
        console.error('Error:', error);
    });
});

document.addEventListener('DOMContentLoaded', function() {
    fetchPlayersAndGame();
    setInterval(fetchPlayersAndGame, 500)
});

var username = sessionStorage.getItem('username');
var current_player = '';

function fetchPlayersAndGame() {
    fetch(`${SERVER_URL}/get_users`)
    .then(response => response.json())
    .then(data => {
        console.log(data);
        const {player_1, player_2} = data;
        if (player_1 == username)
            document.getElementById('players').innerHTML = `X: ${player_1} (You)<br>vs<br> O: ${player_2} (Opponent)`
        else
            document.getElementById('players').innerHTML = `O: ${player_2} (You)<br>vs<br>X: ${player_1} (Opponent)`
    })            
    .catch(error => {
        console.error('Error:', error);
    })

    fetchGameState();
}

function fetchGameState() {
    fetch(`${SERVER_URL}/game_state`)
        .then(response => response.json())
        .then(data => {
            updateUI(data.board);
            current_player = data.current_player;
            document.getElementById('current').textContent = `Current player: ${current_player}`
            checkGameState();
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function updateUI(board) {
    for (let i = 0; i < board.length; i++) {
        document.getElementById(`cell-${i}`).innerText = board[i];
    }
}

function makeMove(index) {
    fetch(`${SERVER_URL}/make_move`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ index: index, username: username }),
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        if (data.success) {
            updateUI(data.board);
            current_player = data.current_player;
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function checkGameState() {
    fetch(`${SERVER_URL}/check_game_state`)
        .then(response => response.json())
        .then(data => {
            if (data.winner || data.draw) {
                document.getElementById('win-info').textContent = data.winner ? `${data.winner} WINS!!` : `IT IS A DRAW!!`;
                document.getElementById('reset-board-btn').style.display = 'block';
            } else {
                document.getElementById('win-info').textContent = ``;
                document.getElementById('reset-board-btn').style.display = 'none';
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}        

function resetBoard() {
    fetch(`${SERVER_URL}/reset_board`)
    .then(response => response.json())
    .then(data => {
        updateUI(data.board);
        current_player = data.current_player;
    })
}