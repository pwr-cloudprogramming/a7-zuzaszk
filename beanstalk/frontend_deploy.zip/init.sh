#!/bin/sh
PUBLIC_IP="backend-266608.us-east-1.elasticbeanstalk.com"
# PUBLIC_IP=$(curl http://169.254.169.254/latest/meta-data/public-ipv4)

cat /usr/share/nginx/html/game.js
sed -i "s|__SERVER_URL__|http://${PUBLIC_IP}|g" /usr/share/nginx/html/game.js
cat /usr/share/nginx/html/game.js

echo "Starting nginx"
echo "Public IP: ${PUBLIC_IP}"
echo "Server URL: http://${PUBLIC_IP}"

nginx -g 'daemon off;'
